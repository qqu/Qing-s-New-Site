The Blueish Cloud growl theme is designed by Victor Erixon and coded by Elliot Jackson.

You can use this theme freely but may not redistribute it anywhere. If you want to share please link to the dribbble shot.

Top Tips:
- Set the opacity to 100%
- Change the animation duration to 5s

Check us out:
Elliot Jackson - twitter.com/_eej  |  dribbble.com/elliotjackson
Victor Erixon - twitter.com/victorerixon  |  dribbble.com/victorerixon